1. Clone the app/ Unzip the app.
2. Run command in terminal with the folder directory.
4. Npm install.
5. After installation.
6. Run Npm Start.